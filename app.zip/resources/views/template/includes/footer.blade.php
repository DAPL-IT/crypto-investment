<div class="footer">
    <div class="copyright">
      <p>Copyright © Designed</p>
    </div>
  </div>
