<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/base_template/vendor/toastr/css/toastr.css')); ?>">
    <link href="<?php echo e(asset('assets/base_template/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>"
        rel="stylesheet">
    <?php echo $__env->yieldContent('extra_css_plugin'); ?>
    <link href="<?php echo e(asset('assets/base_template/css/style.css')); ?>" rel="stylesheet">
    <style>
        html,
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 100vh;
            background: #f3f2f6 !important
        }

        ::placeholder {
            color: rgba(128, 128, 128, 0.5) !important;
            font-size: 9pt !important;
        }

        .password-field {
            padding-right: 40px;
        }

        .password-eye-icon {
            position: absolute;
            top: 52%;
            right: 30px;
        }

        .error-text {
            font-size: 8pt;
            color: rgb(247, 95, 95) !important;
            padding: 0px 25px 15px 25px !important;
            display: none
        }
    </style>
    <?php echo $__env->yieldContent('extra_css'); ?>
</head>

<body>
    <div>
        <div class="container ">
            <div class="row justify-content-center  align-items-center">
                <div class="col-md-6 col-12 py-3">
                    <div class="authincation-content">
                        <?php echo $__env->yieldContent('main_content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/base_template/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/base_template/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/base_template/vendor/toastr/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/base_template/js/toastr-setup.js')); ?>"></script>
    <?php echo $__env->yieldContent('extra_js_plugin'); ?>
    <script src="<?php echo e(asset('assets/base_template/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/base_template/js/deznav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/base_template/js/helper-utilites.js')); ?>"></script>
    <script>
        <?php if(session('alert')): ?>
            <?php if(session('alert')['type'] == 'success'): ?>
                toastr.success("<?php echo e(session('alert')['msg']); ?>")
            <?php elseif(session('alert')['type'] == 'error'): ?>
                toastr.error("<?php echo e(session('alert')['msg']); ?>")
            <?php elseif(session('alert')['type'] == 'warning'): ?>
                toastr.warning("<?php echo e(session('alert')['msg']); ?>")
            <?php elseif(session('alert')['type'] == 'info'): ?>
                toastr.info("<?php echo e(session('alert')['msg']); ?>")
            <?php endif; ?>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>")
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('extra_script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\crypto-investment\resources\views/template/layouts/auth-layout.blade.php ENDPATH**/ ?>