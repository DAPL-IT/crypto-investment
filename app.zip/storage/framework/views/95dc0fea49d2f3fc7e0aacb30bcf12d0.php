<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('template.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Preloader start -->
    <?php echo $__env->make('template.includes.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Preloader end -->

    <!-- Main wrapper start -->
    <div id="main-wrapper">
        <!-- Brand header start -->
        <?php echo $__env->make('template.includes.brand-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Brand header end -->

        <!-- Nav header start -->
        <?php echo $__env->make('template.includes.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Nav header end -->

        <!--  Sidebar start -->
        <?php echo $__env->make('template.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  Sidebar end -->

        <!-- Content body start -->
        <div class="content-body">
            <div class="container mt-0 px-2">
                <?php echo $__env->yieldContent('main_content'); ?>
            </div>
        </div>
        <!-- Content body end -->

        <!-- Footer start -->
        <?php echo $__env->make('template.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer end -->
    </div>
    <!-- Main wrapper end -->

    <!-- Script Section -->
    <?php echo $__env->make('template.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\crypto-investment\resources\views/template/layouts/common-layout.blade.php ENDPATH**/ ?>