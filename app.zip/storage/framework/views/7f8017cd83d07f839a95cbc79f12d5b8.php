<script src="<?php echo e(asset('assets/base_template/vendor/global/global.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/base_template/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/base_template/vendor/toastr/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/base_template/vendor/sweetalert2/dist/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/base_template/js/toastr-setup.js')); ?>"></script>
<?php echo $__env->yieldContent('extra_js_plugin'); ?>
<script src="<?php echo e(asset('assets/base_template/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/base_template/js/deznav-init.js')); ?>"></script>
<script>
    <?php if(session('alert')): ?>
        <?php if(session('alert')['type'] == 'success'): ?>
            toastr.success("<?php echo e(session('alert')['msg']); ?>")
        <?php elseif(session('alert')['type'] == 'error'): ?>
            toastr.error("<?php echo e(session('alert')['msg']); ?>")
        <?php elseif(session('alert')['type'] == 'warning'): ?>
            toastr.warning("<?php echo e(session('alert')['msg']); ?>")
        <?php elseif(session('alert')['type'] == 'info'): ?>
            toastr.info("<?php echo e(session('alert')['msg']); ?>")
        <?php endif; ?>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>")
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>
<?php echo $__env->yieldContent('extra_script'); ?>
<?php /**PATH C:\xampp\htdocs\crypto-investment\resources\views/template/includes/script.blade.php ENDPATH**/ ?>