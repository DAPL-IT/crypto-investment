<div class="footer">
    <div class="copyright">
      <p>Copyright © Designed</p>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\crypto-investment\resources\views/template/includes/footer.blade.php ENDPATH**/ ?>